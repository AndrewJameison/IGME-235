let displayTerm = "";
let url = "";
let offsetValue = 0;

const prefix = "arj5881-";
const favoritesKey = prefix + "favorites";

let localArray = [];

// create a key using the prefix
// create an array object using data from the local storage
    // access the data using the newly created key

// if the object is null, create an empty array

// when the a gif is removed / added to the favorites array
    // update array object
    // update local storage

// display favorites just displays each gif link in the array


window.onload = (e) => {
    document.querySelector("#search").onclick = displaySearch;
    document.querySelector("#favorites").onclick = displayFavorites;
    document.querySelector("#trend").onclick = displayTrending;
    document.querySelector("#next").onclick = nextClicked;
    document.querySelector("#previous").onclick = previousClicked;

    localArray = localStorage.getItem(favoritesKey);

    if (!localArray)
    {
        localArray = [];
    }
} 




function displaySearch() {
    offsetValue = 0;

    console.log("standard search initiated");

    const GIPHY_URL = "https://api.giphy.com/v1/gifs/search?";
    let GIPHY_KEY = "zvaeWpD8U8jaNc39d8kXPgFVFGBGghxm";

    url = GIPHY_URL;
    url += "api_key=" + GIPHY_KEY;

    let limit = document.querySelector('#limit').value;
    url += "&limit=" + limit;

    let rating = document.querySelector('#rating').value;

    if (rating != "none") { url += "&rating=" + rating; } // might not be correct syntax

    let term = document.querySelector("#searchterm").value;
    displayTerm = term;

    term.trim();
    term = encodeURIComponent(term);

    if (term.length < 1) { return; }

    url += "&q=" + term;

    //document.querySelector("#status").innerHTML = "<b>Searching for '" + displayTerm + "'</b>";
     
    console.log(url);

    getData(url);
}

function displayFavorites() {
    offsetValue = 0; // for now, the favorites display will show ALL of the favorites, hopefully able to seperate by offset value down the line

    console.log("pulling up locally stored favorites");

    let bigString = "";

    for (let i = 0; i < localArray.length; i++)
    {
        // each element in the localArray is a div class="result"
            // stored as objects? strings?
            // either append to the content box or add to its innerhtml
    }

    document.querySelector("#content").innerHTML = bigString;
}

function displayTrending() {
    offsetValue = 0;

    console.log("looking for today's trending gifs");
    
    const GIPHY_URL = "https://api.giphy.com/v1/gifs/trending?";
    let GIPHY_KEY = "zvaeWpD8U8jaNc39d8kXPgFVFGBGghxm";

    url = GIPHY_URL;
    url += "api_key=" + GIPHY_KEY;

    let limit = document.querySelector('#limit').value;
    url += "&limit=" + limit;

    let rating = document.querySelector('#rating').value;

    if (rating != "none") { url += "&rating=" + rating; }

    //document.querySelector("#status").innerHTML = "<b>Searching for '" + displayTerm + "'</b>";
     
    console.log(url);

    getData(url);
}





function checkFavorites(e) {
    // search favorites array for the GIF information
    // if found, remove from favorites
    // if not found, add to favorites

    if (localArray.length == 0)
    {
        localArray.push(e.target);
    }

    for (let i = 0; i < localArray.length; i++)
    {
        if (e.target.parentNode == localArray[i])
        {
            localArray.splice(i, 1);
            break;
        }

        if (i == localArray.length - 1)
        {
            localArray.push(e.target.parentNode);
        }
    }

    localStorage.setItem(favoritesKey, localArray);
}

function grabGIF(e) {
    console.log("file has been downloaded! Or maybe copied to clipboard...");
}




function nextClicked() {
    if (url)
    {
        offsetValue += parseInt(document.querySelector('#limit').value);
        
        getData(url + "&offset=" + offsetValue);
    }
}

function previousClicked() {
    if (url)
    {
        offsetValue -= parseInt(document.querySelector('#limit').value);

        if (offsetValue < 0) { offsetValue = 0; }

        getData(url + "&offset=" + offsetValue)
    }
}




function getData(url) {
    let xhr = new XMLHttpRequest();

    xhr.onload = dataLoaded;

    xhr.onerror = dataError;

    xhr.open("GET",url);
    xhr.send();
}



// Callback functions
function dataLoaded(e) {
    let xhr = e.target;

    // console.log(xhr.responseText);

    let obj = JSON.parse(xhr.responseText);

    if (!obj.data || obj.data.length == 0)
    {
        document.querySelector("#status").innerHTML = "<b>No results found for '" + displayTerm + "'</b>";
        return;
    }

    let results = obj.data;

    console.log("results.length = " + results.length);

    let bigString = "";

    for (let i = 0; i < results.length; i++)
    {
        let result = results[i];

        let smallURL = result.images.fixed_width.url;

        if (!smallURL)
        {
            smallURL = "images/no-image-found.png"; // REPLACE IMAGE LINK
        }

        let url = result.url;

        // Each image should display a little star on the button, and if a favorite, fill in the star
        // empty star: &#9734;
        // filled star: &#9733;
        // empty arrow: &#8681
        // either make the font larger, or get an image

        // Rating: ${result.rating.toUpperCase()}<br>

        let line = `<div class='result'><img src='${smallURL}' title='${result.id}'/><br>`;
        line += `<span><a target='_blank' href='${url}'>Source</a></span>`;
        line += `<button type="button" class="favorite">&#9734</button><button type="button" class="download">&#8681</button></div>`;

        bigString += line;
    }

    document.querySelector("#content").innerHTML = bigString;

    for(button of document.querySelectorAll("#content button.favorite"))
    {
        button.onclick = checkFavorites;
    }

    for(button of document.querySelectorAll("#content button.download"))
    {
        button.onclick = grabGIF;
    }

    // document.querySelector("#status").innerHTML = "<b>Success!</b><p><i>Here are " + results.length + " results for '" + displayTerm + "'</i></p>"
}

function dataError(e) {
    console.log("An error occured");
}